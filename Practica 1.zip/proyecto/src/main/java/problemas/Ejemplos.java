package problemas;


public class Ejemplos {

    public static void main(String[] args) {
	String cadena = "774129792679054134423714444344450";

	Double entero = Double.valueOf(cadena);
	System.out.println(entero);
    }


}
