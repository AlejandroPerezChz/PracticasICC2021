package inventario.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import inventario.entidades.Producto;

public class Interfaz { //incluye todos los comentarios de la clase

    public static void muestraBienvenida() {
    	String userName;
    	String x;
        Scanner s = new Scanner( System.in );
        System.out.println( "Hola.\n�Nombre de usuario?: ");
        userName = s.nextLine();
        System.out.println( "Hola " + userName );
        System.out.println( "Esta clase te permitira crear un producto nuevo. Para esto necesitamos la siguiente informaci�n.\n");
        Producto nuevoProducto = new Producto();
        System.out.println("Nombre: ");
        nuevoProducto.setNombre(s.nextLine());
        System.out.println("Tipo: ");
        nuevoProducto.setTipo(s.nextLine());
        System.out.println("Fecha de entrada(DD/MM/AAAA): ");
        try {
			nuevoProducto.setFechaEntrada(new SimpleDateFormat("dd/MM/yyyy").parse(s.nextLine()));
		} catch (ParseException e) {
			System.out.println("Formato de fecha no valido. Favor de ingresar los datos de acuerdo al formato.\nAdios.");
			return;
		}
        System.out.println("Fecha de salida(DD/MM/AAAA): ");
        try {
			nuevoProducto.setFechaSalida(new SimpleDateFormat("dd/MM/yyyy").parse(s.nextLine()));
		} catch (ParseException e) {
			System.out.println("Formato de fecha no valido. Favor de ingresar los datos de acuerdo al formato.\nAdios.");
			return;
		}
        System.out.println("Precio de compra: ");
        try {
			nuevoProducto.setPrecioCompra(Double.parseDouble(s.nextLine()));
		} catch (Exception e) {
			System.out.println("Este campo solo admite valores numericos.\nAdios.");
			return;
		}
        System.out.println("Precio de venta: ");
        try {
			nuevoProducto.setPrecioVenta(Double.parseDouble(s.nextLine()));
		} catch (Exception e) {
			System.out.println("Este campo solo admite valores numericos.\nAdios.");
			return;
		}
        System.out.println("Productor asociado: ");
        nuevoProducto.setProductorA(s.nextLine());
        
        System.out.println(nuevoProducto.mostrarInfo());
        
        System.out.print("\nPrecione enter para terminar...");
        s.nextLine();
        //x = x +" ";
        System.out.println("\nProceso finalzado");
        
        
    }


    public static void main(String[] args) {
	Menu menuInventario = new Menu();

	//Mostrar la bienvenida o instrucciones de uso del sistema..
	muestraBienvenida();
	menuInventario.muestraMenu();
    }
    
}
