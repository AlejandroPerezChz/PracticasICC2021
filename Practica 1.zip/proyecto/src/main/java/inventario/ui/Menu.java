package inventario.ui;

public class Menu {//incluye todos los comentarios de la clase

    /** atributos */
    private String descripcion;
    private String[] opciones; //implementa sus métodos de acceso

    /**
     *
     * COMÉNTAME...
     */
    protected Menu() {
	this.descripcion = "Menú del inventario...";
	this.opciones = new String[4];
	this.opciones[0] = "opción 1";
	//completa la implementación...
    }

    /**
     * Constructor
     * @param descripcion : Instrucciones sobre la interpretación del menú.
     * @param opciones : arreglo con las opciones que formarán parte del menú.
     */
    protected Menu(String descripcion, String[] opciones) {
	//completa la implementación...
    }

    /**
     *
     *
     */
    protected Menu(String descripcion, int numeroOpciones) {
	this.descripcion = descripcion;
	//inicializamos nuestro arreglo de opciones...
    }

    protected void modificaOpcion(String descOpcion, int numeroOpcion) {
	// implementación...
    }

    protected void muestraMenu() {
	//implementación...
    }

     protected void setDescripcion(String descripcion) {
	this.descripcion = descripcion;
    }

    /**
     * COMÉNTAME
     * @return String con la descripción del menú.
     */
    protected String getDescripcion() {
	return this.descripcion;
    }

    // SET OPCIONES
    
    protected String[] getOpciones() {
	return opciones;
    }

}
