package inventario.entidades;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
// bibliotecas usando import
import java.util.Date;

/**
 * Esta clase abstrae la entidad producto dentro de
 * nuestro inventario.
 * 
 * @author leonardo.gallo
 * @since 21/10/2022
 * @version 1
 */
public class Producto {

    /* Atributos */
    String nombre;
    String tipo;
    Date fechaEntrada;
    Date fechaSalida;
    double precioCompra;
    double precioVenta;
    String productorA;

    public Producto() {}

    public void setNombre(String nuevoNombre) {
    	nombre = nuevoNombre;
    }
    public String getNombre() {
    	return nombre;
    }

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public Date getFechaEntrada() {
		return fechaEntrada;
	}

	public void setFechaEntrada(Date fechaEntrada) {
		this.fechaEntrada = fechaEntrada;
	}

	public Date getFechaSalida() {
		return fechaSalida;
	}

	public void setFechaSalida(Date fechaSalida) {
		this.fechaSalida = fechaSalida;
	}

	public double getPrecioCompra() {
		return precioCompra;
	}

	public void setPrecioCompra(double precioCompra) {
		this.precioCompra = precioCompra;
	}

	public double getPrecioVenta() {
		return precioVenta;
	}

	public void setPrecioVenta(double precioVenta) {
		this.precioVenta = precioVenta;
	}

	public String getProductorA() {
		return productorA;
	}

	public void setProductorA(String productorA) {
		this.productorA = productorA;
	}
	
	public String mostrarInfo() {
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		return "\nInformaci�n del producto"+
				"\nNombre de producto: "+nombre+
				"\nTipo de producto: "+tipo+
				"\nFecha de entrada: "+formatter.format(fechaEntrada)+
				"\nFecha de salida: "+formatter.format(fechaSalida)+
				"\nPrecio compra: "+precioCompra+
				"\nPrecio venta: "+precioVenta+
				"\nProductor asociado: "+productorA;
	}

	@Override
	public String toString() {
		return "Producto [nombre=" + nombre + ", tipo=" + tipo + ", fechaEntrada=" + fechaEntrada + ", fechaSalida="
				+ fechaSalida + ", precioCompra=" + precioCompra + ", precioVenta=" + precioVenta + ", productorA="
				+ productorA + "]";
	}
    
    
}
