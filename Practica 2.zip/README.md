* ¿Qué es la notación de camello o CamelCase? 
es una nomenclatura en la que cada palabra dentro de una palabra compuesta se escribe con mayúscula, excepto la primera palabra
*¿Qué otro tipo de notaciones existen?
PascalCase,c,hungara,constantes,identificador
* A qué nos referimos con la expresión “buenas prácticas de programación”.
Una serie de pasos que aunque no sea necesaria es muy recomendable, ya que si utilizas ciertas recomendaciones tu codigo sera mas sencillo de leer y documentar para que tu o mas personas puedan trabajar sobre el mismo archivo a futuro
* ¿Qué dice el documento de convenciones de codificación de java? ¿Por qué es importante conocer 
este tipo de documento en cada lenguaje en el que vayamos a desarrollar? Agrega a tu carpeta _miscelanea_ la versión del documento en inglés y en español.
Las convenciones de código son importantes para los programadores por un gran número de
razones:
· El 80% del coste del código de un programa va a su mantenimiento.
· Casi ningún software lo mantiene toda su vida el auto original.
· Las convenciones de código mejoran la lectura del software, permitiendo entender
código nuevo mucho más rapidamente y más a fondo.
· Si distribuyes tu código fuente como un producto, necesitas asegurarte de que esta
bien hecho y presentado como cualquier otro producto.
* ¿Dónde podemos encontrar toda la documentación del lenguaje java?
https://docs.oracle.com/en/java/
* ¿Qué es una variable estática, cómo se declara y bajo qué circunstancias se usa?
Es una variable que pertenece a la clase en que fue declarada y se inicializa solo una vez al inicio de la ejecución del programa, la característica principal de este tipo de variables es que se puede acceder directamente con el nombre de la clase sin necesidad de crear un objeto,
* ¿Qué es un método estático, cómo se declara y bajo qué circunstancias conviene utilizarlos?
 es un método que pertenece a la clase y no al objeto, puede acceder directamente por el nombre de la clase y no se necesita crear un objeto para acceder al método.
* ¿Qué es una conversión y una promoción (casting and promotion)en java? ¿De qué tipos hay?
es cuando asigna un valor de un tipo de datos primitivo a otro tipo, hay 2 tipos Widening Casting y Narrowing Casting
Incluye tus respuestas en el README de la práctica, en tu carpeta de las prácticas.