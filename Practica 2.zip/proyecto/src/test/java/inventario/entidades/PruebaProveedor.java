package inventario.entidades;

import java.util.Scanner;

public class PruebaProveedor {
	public static void main(String[] args) {
		 Scanner in = new Scanner(System.in);
		 Proveedor productor = new Proveedor();
		 System.out.println("Nombre: ");
		 productor.setNombre(in.nextLine());
		 System.out.println("Tienda: ");
		 productor.setTienda(in.nextLine());
		 System.out.println("Numero de productos entregados: ");
		 productor.setNoProductosEntregados(Integer.parseInt(in.nextLine()));
		 System.out.println("Monto total de productos entregados: ");
		 productor.setTotalMontoProductosEntregados(Float.parseFloat(in.nextLine()));
		 // Salida del dato almacenado
		 System.out.println(productor.imprimirEstadoObjeto());
	    }
}
