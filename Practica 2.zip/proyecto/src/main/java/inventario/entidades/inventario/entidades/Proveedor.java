package inventario.entidades;

import java.util.Scanner;

public class Proveedor {
	String nombre;
	String tienda;
	int noProductosEntregados;
	float totalMontoProductosEntregados;
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTienda() {
		return tienda;
	}
	public void setTienda(String tienda) {
		this.tienda = tienda;
	}
	public int getNoProductosEntregados() {
		return noProductosEntregados;
	}
	public void setNoProductosEntregados(int noProductosEntregados) {
		this.noProductosEntregados = noProductosEntregados;
	}
	public float getTotalMontoProductosEntregados() {
		return totalMontoProductosEntregados;
	}
	public void setTotalMontoProductosEntregados(float totalMontoProductosEntregados) {
		this.totalMontoProductosEntregados = totalMontoProductosEntregados;
	}
	public String imprimirEstadoObjeto() {
		return "Proveedor: \n   Nombre=" + nombre 
				+ "\n   Tienda=" + tienda 
				+ "\n   Productos Entregados=" + noProductosEntregados
				+ "\n   Monto Productos Entregados=" + totalMontoProductosEntregados ;
	}
	public Proveedor creaProveedor() {
		Scanner in = new Scanner(System.in);
		System.out.println("En esta funci�n puedes dar de alta un nuevo proveedor.");
		 Proveedor productor = new Proveedor();
		 System.out.println("Nombre: ");
		 productor.setNombre(in.nextLine());
		 System.out.println("Tienda: ");
		 productor.setTienda(in.nextLine());
		 System.out.println("Numero de productos entregados: ");
		 productor.setNoProductosEntregados(Integer.parseInt(in.nextLine()));
		 System.out.println("Monto total de productos entregados: ");
		 productor.setTotalMontoProductosEntregados(Float.parseFloat(in.nextLine()));
		 // Salida del dato almacenado
		 System.out.println(productor.imprimirEstadoObjeto());
		 System.out.print("\nProducto creado. Precione enter para continuar...");
		 in.nextLine();
		 return productor;
	}
	
}
