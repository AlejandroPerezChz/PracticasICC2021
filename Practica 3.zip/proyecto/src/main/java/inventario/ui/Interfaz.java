package inventario.ui;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import inventario.entidades.Actividad;
import inventario.entidades.Producto;
import inventario.entidades.Proveedor;
import inventario.entidades.Usuario;

public class Interfaz { //incluye todos los comentarios de la clase
	public static Usuario user= new Usuario();
	public static boolean sessionActive = false;
	public static  List<Actividad> actividades =new ArrayList<Actividad>();
	
    public static void muestraBienvenida() {
        Scanner s = new Scanner( System.in );
        System.out.println( "Hola. Bienvenido al sistema de control de inventarios.\n�Nombre de usuario?: ");
        user.setUserName(s.nextLine());
        user.setInicioSesion(new Date());
        sessionActive = true;
        System.out.println( "\nHola " + user.getUserName());
    }


    public static void main(String[] args) {
    	//Metodo1
    	Menu menuInventario = new Menu();
    	//Metodo2
    	//Menu menuInventario = new Menu("\nMen� del inventario\nSeleccione la operaci�n a realizar\n",5);
    	//Metodo3
    	/*String[]opciones = new String[5];
	 	opciones[0] = "Registrar un nuevo producto";
		opciones[1] = "Dar de alta a un nuevo proveedor";
		opciones[2] = "Registrar la salida de un producto";
		opciones[3] = "Eliminar el registro de un proveedor";
		opciones[4] = "Salir";
		Menu menuInventario = new Menu("\nMen� del inventario\nSeleccione la operaci�n a realizar\n",opciones);*/
    	muestraBienvenida();
    	while(sessionActive) {
    		clearScreen();
    		String x = menuInventario.muestraMenu();
    		if(x.equals("1")) {
    			clearScreen();
    			Producto nuevo_producto = new Producto();
    			if(nuevo_producto.creaProducto()==null) {
    				Actividad nueva_actividad = new Actividad();
    				nueva_actividad.setHoraActividad(new Date());
    				nueva_actividad.setDetalle("Alta de producto. Intento fallido.");
    				actividades.add(nueva_actividad);
    			}
    			else {
    				Actividad nueva_actividad = new Actividad();
    				nueva_actividad.setHoraActividad(new Date());
    				nueva_actividad.setDetalle("Alta de producto. Exitoso.");
    				actividades.add(nueva_actividad);
    			}
    		}
    		else if (x.equals("2")) {
    			clearScreen();
    			Proveedor nuevo_proveedor = new Proveedor();
    			nuevo_proveedor.creaProveedor();
    			Actividad nueva_actividad = new Actividad();
				nueva_actividad.setHoraActividad(new Date());
				nueva_actividad.setDetalle("Alta de proveedor.");
				actividades.add(nueva_actividad);
    		}
    		else if (x.equals("3")) {
    			clearScreen();
    			Scanner s = new Scanner( System.in );
    	        System.out.println( "Implementaci�n en proceso.");
    	        System.out.print("\nProducto creado. Precione enter para continuar...");
    	        s.nextLine();
    		}
    		else if (x.equals("4")) {
    			clearScreen();
    			Scanner s = new Scanner( System.in );
    	        System.out.println( "Implementaci�n en proceso.");
    	        System.out.print("\nProducto creado. Precione enter para continuar...");
    	        s.nextLine();
    		}
    		else if (x.equals("5")) {
    			clearScreen();
    			sessionActive = false;
    			user.setActividades(actividades);
    			user.setFinalSesion(new Date());
    			System.out.println(user.muesstraLog());
    			System.out.println("\nHasta luego...");
    		}
    		else {
    			clearScreen();
    			Scanner s = new Scanner( System.in );
    	        System.out.println("Opci�n no valida.");
    	        System.out.print("\nProducto creado. Precione enter para continuar...");
    	        s.nextLine();
    		}
    	}
    }
    
    public static void clearScreen() {
    	for (int i = 0; i < 50; ++i) System.out.println();
    }
    
}
