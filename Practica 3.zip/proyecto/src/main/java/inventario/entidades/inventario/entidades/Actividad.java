package inventario.entidades;

import java.util.Date;

public class Actividad {

	String detalle;
	Date horaActividad;
	
	public String getDetalle() {
		return detalle;
	}
	public void setDetalle(String detalle) {
		this.detalle = detalle;
	}
	public Date getHoraActividad() {
		return horaActividad;
	}
	public void setHoraActividad(Date horaActividad) {
		this.horaActividad = horaActividad;
	} 
}
