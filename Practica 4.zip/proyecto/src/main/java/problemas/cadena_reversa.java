package problemas;

public class cadena_reversa {

	
	public String invertir(String s) {
		String rs="";
		for(int i =(s.length()-1);i>=0;i--) {
			rs = rs+s.charAt(i);
		}
		System.out.println(rs);
		return rs;
	}
}
