package inventario.entidades;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Alimento extends Producto{
	public Date fechaDeCaducidad;
	public double temperaturaDeAlmacenamiento;
	
	public Alimento(Producto fuente) {
		heredar(fuente,this);
	}
	
	public static void heredar(Producto fuente, Alimento destino) {
		destino.setNombre(fuente.getNombre());
		destino.setPrecioCompra(fuente.getPrecioCompra());
		destino.setPrecioVenta(fuente.getPrecioVenta());
		destino.setFechaEntrada(fuente.fechaEntrada);
		destino.setFechaSalida(fuente.getFechaSalida());
		destino.setProductorA(fuente.getProductorA());
		destino.setTipo(fuente.getTipo());
		System.out.println("Fecha de caducidad(DD/MM/AAAA): ");
		Scanner s = new Scanner( System.in );
		try {
			destino.setFechaDeCaducidad(new SimpleDateFormat("dd/MM/yyyy").parse(s.nextLine()));
		} catch (ParseException e) {
			System.out.println("Formato de fecha no valido. Favor de ingresar los datos de acuerdo al formato.");
		}
		System.out.println("Temperartura de almacenamiento: ");
        try {
        	String rest =s.nextLine();
        	System.out.println(rest);
        	destino.setTemperaturaDeAlmacenamiento(Double.parseDouble(rest));
		} catch (Exception e) {
			System.out.println("Este campo solo admite valores numericos.");
		}
	}

	public Date getFechaDeCaducidad() {
		return fechaDeCaducidad;
	}

	public void setFechaDeCaducidad(Date fechaDeCaducidad) {
		this.fechaDeCaducidad = fechaDeCaducidad;
	}

	public double getTemperaturaDeAlmacenamiento() {
		return temperaturaDeAlmacenamiento;
	}

	public void setTemperaturaDeAlmacenamiento(double temperaturaDeAlmacenamiento) {
		this.temperaturaDeAlmacenamiento = temperaturaDeAlmacenamiento;
	}

	@Override
	public String toString() {
		return "Alimento [fechaDeCaducidad=" + fechaDeCaducidad + ", temperaturaDeAlmacenamiento="
				+ temperaturaDeAlmacenamiento + ", nombre=" + nombre + ", tipo=" + tipo + ", fechaEntrada="
				+ fechaEntrada + ", fechaSalida=" + fechaSalida + ", precioCompra=" + precioCompra + ", precioVenta="
				+ precioVenta + ", productorA=" + productorA + "]";
	}
	
	
}
